<?php
    $currentRouteName = Route::currentRouteName();
?>

<?php $__env->startSection('content'); ?>
        <div id="layoutSidenav_content">
            <main>
                <br>
                <div class="container-fluid px-4">
                    <h1 class="mt-4">Pemasukan</h1>
                    <br>
                    <div class="col-lg-3 col-xl-2">
                        <div class="d-grid gap-2">

                            <a href="<?php echo e(route('pemasukan.create')); ?>" class="btn btn-primary rounded-pill" style="background-color: #58B079" >Tambah Pemasukan</a>
                        </div>
                    </div>
                    <br>
                    <div class="table-responsive border p-3 rounded-3" style="background-color: #FDDDCB">
                        <table class="table table-bordered table-hover table-striped mb-0 bg-white datatable" id="employeeTable">
                            <thead>
                                <tr class="text-center">
                                    <th>No</th>
                                    <th>Nama Kategori</th>
                                    <th>Nominal</th>
                                    <th>Deskripsi</th>
                                    <th>Tanggal</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $counter = 1;
                            ?>

                                <?php $__currentLoopData = $pemasukans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pemasukan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($counter); ?></td>

                                    <td><?php echo e($pemasukan->kategorimasuk->nama_kategori); ?></td>
                                    <td><?php echo e($pemasukan->nominal); ?></td>
                                    <td><?php echo e($pemasukan->deskripsi); ?></td>
                                    <td><?php echo e($pemasukan->tanggal_pemasukan); ?></td>
                                    <td><?php echo e($pemasukan->user->name); ?></td>
                                    <td>
                                        <div class="d-flex">
                                                <a href="<?php echo e(route('pemasukan.edit', ['pemasukan'=>$pemasukan->id])); ?>" class="btn btn-outline-dark btn-sm
                                                    me-2"><i class="bi-pencil-square"></i></a>
                                            </div>
                                            <form action="<?php echo e(route('pemasukan.destroy',['pemasukan' =>$pemasukan->id])); ?>" method="POST"> <?php echo csrf_field(); ?> <?php echo method_field('delete'); ?>
                                            <button type="submit" class="btn btn-outline-dark btn-sm me-2"><i class="bi-trash"></i></button>

                                            </form>
                                        </div>
                                    </div>
                                    </td>
                                </tr>
                                <?php
                                $counter++;
                            ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                    </div>
            </main>
            <footer class="py-4 bg-light mt-auto">
                <div class="container-fluid px-4">
                    <div class="d-flex align-items-center justify-content-center small">
                        <div class="text-center">Copyright &copy; Iqbal 2023</div>
                    </div>
                </div>
            </footer>
        </div>
    </div>
    <?php $__env->stopSection(); ?>
        

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\New folder (3)\cloneprojectlaravel\resources\views/pemasukan/index.blade.php ENDPATH**/ ?>
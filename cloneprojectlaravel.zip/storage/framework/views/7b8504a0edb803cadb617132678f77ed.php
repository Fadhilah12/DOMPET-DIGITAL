<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e($pageTitle); ?></title>
    <?php echo app('Illuminate\Foundation\Vite')('resources/sass/app.scss'); ?>
</head>
<body>

    <div class="container-sm mt-5" >
        <form action="<?php echo e(route('pemasukan.store')); ?>" method="POST" >
            <?php echo csrf_field(); ?>
            <div class="row justify-content-center"  >
                <div class="p-4 rounded-4 border col-xl-6" style="background-color: #FDDDCB" >

                    <?php if($errors->any()): ?>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="alert alert-danger alert-dismissible fade show">
                               <?php echo e($error); ?>

                               <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>

                        <div class="mb-3 text-center" >
                            <svg xmlns="http://www.w3.org/2000/svg" width="80" height="80" viewBox="0 0 24 24"><path fill="currentColor" d="M3 6h18v12H3V6m9 3a3 3 0 0 1 3 3a3 3 0 0 1-3 3a3 3 0 0 1-3-3a3 3 0 0 1 3-3M7 8a2 2 0 0 1-2 2v4a2 2 0 0 1 2 2h10a2 2 0 0 1 2-2v-4a2 2 0 0 1-2-2H7Z"/></svg>
                            <h4>Tambah Pemasukan </h4>
                        </div>
                        <hr style="border: 3px solid #CA3B44;">
                        <div class="row" >
                            <div class="col-md-12 mb-3" >
                                <label for="kategori" class="form-label">Kategori</label>
                                <select name="kategori_id" id="kategori_id" class="form-select">
                                    <?php $__currentLoopData = $pemasukans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($kategori->id); ?>" <?php echo e($kategori->id == $kategori->id ?'selected' : ''); ?>><?php echo e($kategori->kode_kategori.' -'.$kategori->nama_kategori); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="nominal" class="form-label">Nominal</label>
                                <input class="form-control" type="number" name="nominal" id="nominal" value="" placeholder="Masukkan harga">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="floatingTextarea">Deskripsi</label>
                                <textarea class="form-control" placeholder="Tuliskan deskripsi pemasukan" name="deskripsi" id="deskripsi"></textarea>
                            </div>
                            <div class="col-md-4 mb-8">
                                <label for="tanggal">Tanggal</label>
                                <input type="datetime-local" name="tanggal_pemasukan" id="tanggal_pemasukan">
                            </div>
                        </div>
                        <hr style="border: 3px solid #CA3B44;">
                        <div class="row">
                            <div class="col-md-6 d-grid">
                                <a href="<?php echo e(route('pemasukan.index')); ?>" class="btn btn-danger mt-3"><i class="bi-arrow-left-circle me-2" ></i> Cancel</a>
                            </div>
                            <div class="col-md-6 d-grid" >
                                <button type="submit" class="btn btn-success mt-3"><i class="bi-check-circle me-2" ></i> Save</button>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>

        <?php echo app('Illuminate\Foundation\Vite')('resources/js/app.js'); ?>
    </body>
    </html>
<?php /**PATH D:\New folder (3)\cloneprojectlaravel\resources\views/pemasukan/create.blade.php ENDPATH**/ ?>
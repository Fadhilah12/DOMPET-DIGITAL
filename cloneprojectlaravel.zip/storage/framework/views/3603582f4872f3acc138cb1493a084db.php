<?php
    $currentRouteName = Route::currentRouteName();
?>


<?php $__env->startSection('content'); ?>
        <div id="layoutSidenav_content">
            <main>
                <div class="container-fluid px-4">
                    <br>
                    <h1 class="mt-4">Pengeluaran</h1>
                    <br>
                    <div class="col-lg-3 col-xl-2">
                        <div class="d-grid gap-2">
                            <a href="<?php echo e(route('pengeluaran.create')); ?>" class="btn btn-success">Create Pengeluaran</a>
                        </div>
                    </div>
                    <br>
                    </div>
                    <div class="table-responsive border p-3 rounded-3" style="background-color: #FDDDCB">
                        <table class="table table-bordered table-hover table-striped mb-0 bg-white datatable" id="employeeTable">
                            <thead>
                                <tr class="text-center">
                                    <th>No</th>
                                    <th>Nama Kategori</th>
                                    <th>nominal</th>
                                    <th>deskripsi</th>
                                    <th>tgl pemasukan</th>
                                    <th>username</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $counter = 1;
                            ?>
                                <?php $__currentLoopData = $pengeluaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pengeluarans): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($counter); ?></td>
                                    <td><?php echo e($pengeluarans->kategorikeluar->nama_kategori); ?></td>
                                    <td><?php echo e($pengeluarans->nominal); ?></td>
                                    <td><?php echo e($pengeluarans->deskripsi); ?></td>
                                    <td><?php echo e($pengeluarans->tanggal_pengeluaran); ?></td>
                                    <td><?php echo e($pengeluarans->user->name); ?></td>
                                    <td>
                                        <div class="d-flex">
                                                <a href="<?php echo e(route('pengeluaran.edit', ['pengeluaran'=>$pengeluarans->id])); ?>" class="btn btn-outline-dark btn-sm
                                                    me-2"><i class="bi-pencil-square"></i></a>
                                            </div>
                                            <form action="<?php echo e(route('pengeluaran.destroy',['pengeluaran' =>$pengeluarans->id])); ?>" method="POST"> <?php echo csrf_field(); ?> <?php echo method_field('delete'); ?>
                                            <button type="submit" class="btn btn-outline-dark btn-sm me-2"><i class="bi-trash"></i></button>
                                            </form>

                                        </div>
                                        <form action="<?php echo e(route('pengeluaran.destroy',['pengeluaran' =>$pengeluarans->id])); ?>" method="POST"> <?php echo csrf_field(); ?> <?php echo method_field('delete'); ?>
                                        <button type="submit" class="btn btn-outline-danger btn-sm me-2"><i class="bi-trash"></i></button>
                                        </form>
                                    </div>
                                </td>
                                </tr>
                                <?php
                                $counter++;
                            ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                    </div>
            </main>
            <footer class="py-4 bg-light mt-auto">
                <div class="container-fluid px-4">
                    <div class="d-flex align-items-center justify-content-center small">
                        <div class="text-center">Copyright &copy; Iqbal 2023</div>
                    </div>
                </div>
            </footer>
        </div>
    </div>
    <?php $__env->stopSection(); ?>
        

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\New folder (3)\cloneprojectlaravel\resources\views/pengeluaran/index.blade.php ENDPATH**/ ?>